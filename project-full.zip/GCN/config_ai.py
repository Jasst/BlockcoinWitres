"""
Централизованная конфигурация для всей AI-системы (когнитивная архитектура + GCN)
"""
import os
from pathlib import Path

# -------------------------------
# Общие пути
# -------------------------------
MEMORY_BASE_DIR = Path(__file__).resolve().parent.parent / "ai_memory_v3"
MEMORY_BASE_DIR.mkdir(exist_ok=True)

# -------------------------------
# LLM (LM Studio)
# -------------------------------
LM_STUDIO_URL = "http://localhost:1234/v1/chat/completions"
LM_STUDIO_API_KEY = "lm-studio"
LM_STUDIO_TIMEOUT = 1800          # увеличено с 600 до 1800 сек (30 мин) для длительных запросов
LM_STUDIO_STREAM_TIMEOUT = 2700   # увеличено с 900 до 2700 сек (45 мин) для потоковых ответов
LM_STUDIO_USE_STREAM = True
LM_STUDIO_VISION_SUPPORTED = True
DEFAULT_MAX_TOKENS = 4096         # увеличенная длина ответа по умолчанию (было 2048)

# -------------------------------
# Reasoning / теги <thought>
# -------------------------------
# Переключатели для принудительного формирования рассуждений моделью.
# Вынесены в конфиг, чтобы можно было настраивать без правки кода.
REASONING_FORCE_TAGS = True       # обязывать модель писать <thought>...</thought>
REASONING_FEW_SHOT = True         # добавлять few-shot примеры формата
# stop-токены для reasoning-режима (пустой tuple = не использовать)
REASONING_STOP_TOKENS: tuple = ()

# НОВОЕ: reasoning съедает много токенов ДО первого символа ответа.
# Модель, у которой reasoning_content съел весь бюджет (наблюдалось: 500
# токенов — и content="" пустой), — это не «не ответила», а «не уложилась».
# Поэтому для ходов с включённым reasoning используем буст к обычному
# DEFAULT_MAX_TOKENS. 4096 + 4096 = 8192 — комфортный запас и для thinking,
# и для ответа. Если у модели context window меньше 16k — уменьшай.
REASONING_MAX_TOKENS_BOOST = 4096

# -------------------------------
# Параметры памяти (GCN)
# -------------------------------
WORKING_MEMORY_SIZE = 40
SENSORY_BUFFER_SIZE = 5
EPISODIC_MAX_SIZE = 1000
SEMANTIC_MAX_FACTS = 100000
ASSOCIATIVE_GRAPH_MAX_NODES = 200000
DEFAULT_CONFIDENCE = 0.5
DEFAULT_IMPORTANCE = 1.0

# -------------------------------
# Гибридный поиск (GCN)
# -------------------------------
HYBRID_WEIGHT_SEMANTIC = 0.40      # вес семантического (эмбеддинги)
HYBRID_WEIGHT_GRAPH = 0.30         # вес графовых связей
HYBRID_WEIGHT_FRESHNESS = 0.15     # вес свежести
HYBRID_WEIGHT_EVIDENCE = 0.10      # вес количества доказательств
HYBRID_WEIGHT_CONFIDENCE = 0.05    # вес доверия
DYNAMIC_WEIGHTS_ENABLED = True

# -------------------------------
# Эмбеддинги (SentenceTransformer + FAISS)
# -------------------------------
# ИСПРАВЛЕНИЕ #1: EMBEDDING_DIM теперь определяется динамически из модели,
# а не захардкожено. Значение 384 соответствует paraphrase-multilingual-MiniLM-L12-v2
# и all-MiniLM-L6-v2. Для multilingual-e5-large используется 1024.
# Реальная размерность берётся из model.get_sentence_embedding_dimension()
# в memory_graph.py:CognitiveMemory.__init__().
EMBEDDING_DIM = 384                # размерность векторов (по умолчанию для MiniLM)
USE_EMBEDDINGS = True
GLOBAL_FACT_CONFIDENCE_THRESHOLD = 0.75

# -------------------------------
# GCN-специфичные параметры
# -------------------------------
GCN_STATE_FILENAME = "gcn_state.json"
GCN_AUTO_VERIFY = True
GCN_EVIDENCE_THRESHOLD = 0.6

# -------------------------------
# Консолидация и сон
# -------------------------------
CONSOLIDATION_INTERVAL = 3600 * 2
DEEP_CONSOLIDATION_INTERVAL = 3600 * 8
REPLAY_BATCH_SIZE = 20
REPLAY_MIX_RATIO = (0.4, 0.3, 0.2, 0.1)

# -------------------------------
# Любопытство и автономность
# -------------------------------
CURIOSITY_UNCERTAINTY_THRESHOLD = 0.7
CURIOSITY_NOVELTY_THRESHOLD = 0.6
CURIOSITY_RESEARCH_INTERVAL = 600
RESOURCE_BUDGET_LLM_CALLS = 100
# BUGFIX: флаг был False, из-за чего AutonomyEngine (enqueue_topic/_pump_queue)
# молча отклонял/вычищал все темы — фоновое исследование не работало вообще.
# Legacy _auto_research по-прежнему гасится этим флагом в ai_assistant._periodic_research.
AUTO_RESEARCH_ENABLED = True

# -------------------------------
# Веб-поиск
# -------------------------------
MAX_SEARCH_ITERATIONS = 3
SEARCH_CACHE_TTL = 300
PAGE_CONTENT_MAX_CHARS = 6000
MAX_PAGES_TO_FETCH = 7
MIN_RELEVANCE_THRESHOLD = 0.28
CHUNK_SIZE = 1200
CHUNK_OVERLAP = 150
PARALLEL_FETCH_LIMIT = 8
DDG_MIN_INTERVAL = 1.2
DDG_MAX_RETRIES = 3
SEARCH_CACHE_MAX_SIZE = 200
AUTO_SEARCH_ENABLED = True
MAX_SEARCH_ATTEMPTS = 3
ENABLE_QUERY_REWRITE = True
EXTRACT_FACTS_FROM_SEARCH = True
EXTRACT_FACTS_WITH_LLM = True
DEEP_SEARCH_TOTAL_BUDGET = 15

# -------------------------------
# Планировщик целей
# -------------------------------
LONG_TERM_PLANNER_INTERVAL = 3600 * 6
GOAL_MAX_ACTIVE = 5

# -------------------------------
# Команды управления памятью (дополнительные триггеры для гибкости)
# -------------------------------
MEMORY_CONTROL_COMMANDS = {
    "запомни в shared": "store_shared",  # ← НОВОЕ (должно быть ПЕРВЫМ, т.к. длиннее)
    "запомни глобально": "store_global",  # ← НОВОЕ
    "запомни": "store",
    "забудь": "forget",
    "что ты знаешь о": "recall",
    "напомни о": "recall",
    "сохрани": "store",
    "удали": "forget",
}

# -------------------------------
# Генерация изображений
# -------------------------------
EASYDIFFUSION_ENABLED = True
EASYDIFFUSION_URL = "http://localhost:7860"
EASYDIFFUSION_ENDPOINT = "/v1/sdapi/v1/txt2img"
EASYDIFFUSION_TIMEOUT = 140
EASYDIFFUSION_DEFAULT_STEPS = 20
EASYDIFFUSION_DEFAULT_WIDTH = 512
EASYDIFFUSION_DEFAULT_HEIGHT = 512

EASYDIFFUSION_DEFAULT_LORA_USE = True
EASYDIFFUSION_DEFAULT_LORA = "E:/Easy-Diffusion/models/lora/Realism Lora By Stable Yogi_V3_Lite.safetensors"
EASYDIFFUSION_DEFAULT_LORA_WEIGHT = 0.8

EASYDIFFUSION_MODEL = "realismByStableYogi_ponyV65.safetensors"   # <-- добавьте эту строку
# Раньше был жёстко зашит Windows-путь "E:/BlockcoinWitres/generated_images" —
# на любой другой машине (в т.ч. на Linux self-hosted сервере) mkdir() на
# этом пути падал бы сразу. По умолчанию кладём рядом с MEMORY_BASE_DIR,
# путь можно переопределить через переменную окружения GENERATED_IMAGES_DIR.
GENERATED_IMAGES_DIR = Path(
    os.environ.get("GENERATED_IMAGES_DIR", str(MEMORY_BASE_DIR.parent / "generated_images"))
)
GENERATED_IMAGES_DIR.mkdir(parents=True, exist_ok=True)

# -------------------------------
# Тайм-ауты и надёжность вызова инструментов (internal + MCP)
# -------------------------------
# Раньше вызов инструмента (особенно внешнего MCP-сервера) ничем не был
# ограничен по времени — если сервер/локальная LLM внутри него подвиснет,
# весь ответ чата зависал без вариантов восстановления.
TOOL_CALL_TIMEOUT_SECONDS = 45
# Периодичность повторных попыток подключиться к упавшим при старте MCP-серверам.
MCP_RECONNECT_INTERVAL = 120

# ИСПРАВЛЕНИЕ (рассинхронизация клиентского и серверного таймаута MCP):
# mcp_client_manager.MCPToolManager.call_tool раньше всегда ждал ровно
# TOOL_CALL_TIMEOUT_SECONDS (45с) для ЛЮБОГО инструмента любого внешнего
# MCP-сервера. При этом mcp_server_blockcoin.py сам себе на стороне сервера
# даёт до 300с на generate_image и до 240с на research_topic
# (_MCP_IMAGE_TOOL_TIMEOUT_SECONDS/_MCP_RESEARCH_TOOL_TIMEOUT_SECONDS) — то
# есть клиент обрывал вызов и возвращал "не ответил за 45с" за много секунд
# ДО того, как сервер вообще успевал закончить генерацию/исследование,
# которые сами по себе не зависли и продолжали бы работать. Ключи — это
# подстроки, которые ищутся в original_tool_name вызываемого инструмента
# (без учёта регистра); используется первое совпадение, иначе — обычный
# TOOL_CALL_TIMEOUT_SECONDS.
MCP_TOOL_TIMEOUT_OVERRIDES = {
    "generate_image": 300,
    "research_topic": 240,
    "web_search": 90,
}

# -------------------------------
# Таймауты постобработки ответа (_finalize_answer)
# -------------------------------
# _finalize_answer вызывает до трёх LLM-вызовов ПОСЛЕ того, как все токены
# ответа уже отправлены во фронтенд: plan_critic (проверяет план подзадач),
# verify_response (фактическая верификация), ensure_citations. Без таймаутов
# зависший LM Studio блокирует отправку [DONE] → пользователь видит "готовый"
# ответ, но поле ввода заблокировано (_isSending = true), и новое сообщение
# отправить невозможно. Теперь при превышении лимита _finalize_answer
# переносится в фоновую задачу (без push), а [DONE] уходит немедленно.
PLAN_CRITIC_TIMEOUT = 15.0       # сек на один вызов plan_critic + LLM-добор
VERIFY_RESPONSE_TIMEOUT = 10.0   # сек на верификационный LLM-вызов
FINALIZE_ANSWER_TIMEOUT = 90.0   # увеличено с 35.0 до 90 сек — суммарный бюджет на все этапы финализации

# -------------------------------
# Прочее
# -------------------------------
STREAM_CHAR_BY_CHAR = False
STREAM_CHAR_DELAY = 0.02
MAX_IMAGE_SIZE_BASE64 = 5 * 1024 * 1024
MAX_MESSAGE_LENGTH = 10000
MIN_MESSAGE_LENGTH = 1

# -------------------------------
# Кэш памяти
# -------------------------------
MEMORY_CACHE_TTL = 60
MEMORY_CACHE_MAX_SIZE = 1000

# -------------------------------
# Дубликаты (light consolidation)
# -------------------------------
DUPLICATE_SIMILARITY_THRESHOLD = 0.92

# -------------------------------
# Рефлексия (самообучение)
# -------------------------------
REFLECTION_INTERVAL = 3600 * 4
REFLECTION_ERROR_THRESHOLD = 0.6
REFLECTION_HISTORY_SIZE = 100
REFLECTION_LLM_TEMP = 0.5
REFLECTION_LLM_MAX_TOKENS = 300

# -------------------------------
# Самоанализ кода (Code Self-Reflection)
# -------------------------------
# Позволяет ИИ читать свой код, анализировать ошибки и предлагать исправления
ENABLE_CODE_SELF_REFLECTION = True
CODE_ANALYSIS_MAX_FILES = 10  # лимит файлов за один анализ
CODE_CONTEXT_MAX_LINES = 50  # макс. строк контекста вокруг ошибки
AUTO_FIX_SUGGESTIONS = True  # предлагать исправления автоматически
CODE_ACCESS_ROOT = Path(__file__).resolve().parent.parent  # корень для доступа к коду
ALLOWED_CODE_EXTENSIONS = {".py", ".json", ".md", ".txt", ".yml", ".yaml"}  # безопасные расширения

# -------------------------------
# Проактивные уведомления
# -------------------------------
# Фоновые циклы (авто-исследование по целям, доисследование тем из
# рефлексии) и так уже работают автономно — не хватало только канала,
# которым их находки долетают до пользователя, не дожидаясь вопроса.
# Ниже — настройки для решения "стоит ли сказать" и для троттлинга,
# чтобы не превращать это в спам. Список активен и для основного чата
# (ai_assistant.py), и для отдельного процесса MCP-сервера
# (mcp_server_blockcoin.py) — оба пишут находки в общий GCN-стор.
PROACTIVE_NOTIFICATIONS_ENABLED = True
# Минимальный интервал между проактивными сообщениями одному пользователю,
# независимо от того, сколько фоновых циклов отработало за это время.
PROACTIVE_MESSAGE_COOLDOWN_SECONDS = 3 * 3600
PROACTIVE_NOTIFICATION_MAX_TOKENS = 150
# LLM сама решает, тривиальна ли находка (отвечает NONE) или стоит
# сообщить (тогда отвечает готовой репликой от первого лица).
PROACTIVE_NOTIFICATION_PROMPT = (
    "Ты — ассистент, который только что в фоне ({source_label}) получил результат "
    "по теме, важной для пользователя, не дожидаясь его вопроса.\n\n"
    "Результат:\n{finding}\n\n"
    "Реши, стоит ли сообщать об этом пользователю прямо сейчас.\n"
    "Если результат тривиален, неуверен, слишком расплывчат или неинтересен — "
    "ответь ровно одним словом: NONE.\n"
    "Если стоит — ответь ОДНИМ коротким сообщением от первого лица (1-2 предложения, "
    "разговорным тоном, как будто сам вспомнил и решил поделиться), без списков, "
    "заголовков и вступлений вроде «вот что я нашёл»."
)

# -------------------------------
# Когнитивные дефолты фактов (memory_graph.Fact)
# -------------------------------
DEFAULT_NOVELTY = 0.0
DEFAULT_SALIENCE = 0.0
DEFAULT_STABILITY = 0.5
DEFAULT_PLASTICITY = 0.5
DEFAULT_PREDICTION_ERROR = 0.0

# -------------------------------
# Метакогнитивный мониторинг (НОВЫЙ раздел)
# -------------------------------
# Включение метакогнитивной проверки перед выполнением действий.
# Система оценивает свою уверенность в конкретной области через SelfModel
# и блокирует действия с низкой уверенностью (< METACOGNITION_CONFIDENCE_THRESHOLD).
METACOGNITION_ENABLED = True
# Порог уверенности для выполнения действий. При значении ниже этого порога
# действие блокируется или требует уточнения/альтернативы.
METACOGNITION_CONFIDENCE_THRESHOLD = 0.4

# -------------------------------
# Синапсы / Hebbian / STDP (memory_graph.Synapse)
# -------------------------------
SYNAPSE_INITIAL_WEIGHT = 0.1
SYNAPSE_MAX_WEIGHT = 1.0
SYNAPSE_MIN_WEIGHT = 0.01
SYNAPSE_DECAY_RATE = 0.001
SYNAPSE_PLASTICITY_RATE = 0.01
SYNAPSE_COACTIVATION_THRESHOLD = 0.3
HEBBIAN_LEARNING_RATE = 0.02
STDP_LEARNING_RATE = 0.03
STDP_TIME_WINDOW = 5.0
STDP_LONG_TERM_POTENTIATION = 0.01
STDP_LONG_TERM_DEPRESSION = 0.005

# -------------------------------
# Spreading activation
# -------------------------------
SPREADING_MAX_DEPTH = 3
SPREADING_MAX_NODES = 50
SPREADING_DECAY = 0.5
SPREADING_THRESHOLD = 0.05

# -------------------------------
# Предсказательная матрица
# -------------------------------
PREDICTIVE_MATRIX_MAX_SIZE = 5000
PREDICTIVE_LEARNING_RATE = 0.1
PREDICTION_ERROR_THRESHOLD = 0.3

# -------------------------------
# Эмбеддинги для CognitiveMemory (SentenceTransformer + FAISS)
# -------------------------------
# ИСПРАВЛЕНИЕ (пункт №1 из анализа интеллекта): all-mpnet-base-v2 —
# англоцентричная модель. Основной язык диалогов — русский, а семантический
# канал (HYBRID_WEIGHT_SEMANTIC/HYBRID_WEIGHT_COSINE) — самый весомый канал
# гибридного поиска, поэтому слабое качество эмбеддингов на русском напрямую
# било по релевантности всего, что подмешивается в промпт как "самый
# надёжный источник". multilingual-e5-large — сильная мультиязычная модель
# с хорошим покрытием русского. Если ресурсы (VRAM/RAM) ограничены — можно
# заменить на более лёгкую "intfloat/multilingual-e5-base" (тот же протокол
# query:/passage:, размерность вектора меньше, качество чуть ниже).
MEMORY_USE_EMBEDDINGS = True
EMBEDDING_MODEL = "intfloat/multilingual-e5-large"
# Модели семейства e5 обучены с асимметричными префиксами: текст запроса и
# текст сохраняемого факта эмбеддятся по-разному ("query: "/"passage: "),
# это даёт заметно более точный поиск, чем эмбеддинг без префиксов. Для
# моделей, которые в этом не нуждаются, можно оставить обе строки пустыми.
EMBEDDING_QUERY_PREFIX = "query: "
EMBEDDING_PASSAGE_PREFIX = "passage: "
FAISS_NLIST = 200
FAISS_NPROBE = 30
FAISS_REBUILD_THRESHOLD = 300
FAISS_MIN_TRAIN_VECTORS = 500

# -------------------------------
# Гибридный поиск (memory_graph.retrieve_hybrid)
# -------------------------------
HYBRID_WEIGHT_BM25 = 0.25
HYBRID_WEIGHT_COSINE = 0.40

# -------------------------------
# FAISS адаптивные пороги
# -------------------------------
FAISS_SMALL_THRESHOLD = 50
FAISS_MEDIUM_THRESHOLD = 500
FAISS_HNSW_EF_CONSTRUCTION = 80
FAISS_HNSW_M = 32

# ===== НОВЫЕ ПАРАМЕТРЫ ДЛЯ УЛУЧШЕНИЙ =====

# Классификация намерений (если False, используем старую логику)
ENABLE_INTENT_CLASSIFICATION = True

# Автоматическое извлечение фактов из сообщений (без команды)
AUTO_EXTRACT_FACTS = True
AUTO_EXTRACT_CONFIDENCE = 0.5

# Порог уверенности для автоматического запоминания
AUTO_EXTRACT_THRESHOLD = 0.6

# Время бездействия для запуска консолидации (секунды)
IDLE_CONSOLIDATION_DELAY = 900  # 15 минут

# -------------------------------
# Формирование концептов (абстрагирование, шаг эмерджентности)
# -------------------------------
CONCEPT_MIN_CLUSTER_SIZE = 3        # минимум фактов в кластере, чтобы сформировать концепт
CONCEPT_SIMILARITY_THRESHOLD = 0.6  # порог косинусной близости для объединения в кластер
CONCEPT_MAX_SCAN = 2000             # лимит сканируемых фактов за один запуск (O(n^2) по эмбеддингам)
CONCEPT_MAX_PER_RUN = 5             # не больше стольких новых концептов за один цикл консолидации

# -------------------------------
# Кросс-слойное заземление (PRIVATE/SHARED -> GLOBAL через GROUNDS_IN)
# -------------------------------
CROSS_LAYER_GROUNDING_THRESHOLD = 0.75

# -------------------------------
# LLM-реранкинг результатов памяти (пункт №2 из анализа интеллекта)
# -------------------------------
# hybrid_retrieve/retrieve_hybrid отдают top_k по линейной взвешенной сумме
# (семантика+граф+свежесть+confidence+evidence) — это хорошо отсеивает явно
# нерелевантное, но плохо разруливает "похожее по вектору, но не по сути"
# кандидатов. RERANK_ENABLED включает лёгкий LLM-судью поверх уже
# найденных кандидатов GCNMemoryRouter.retrieve(): берём с запасом
# (top_k * RERANK_CANDIDATE_MULTIPLIER, но не больше RERANK_MAX_CANDIDATES),
# просим модель выбрать и упорядочить только реально релевантные — и уже
# из этого списка обрезаем до top_k. При сбое LLM или пустом ответе всегда
# безопасно откатываемся на исходный порядок (см. GCNMemoryRouter._llm_rerank).
RERANK_ENABLED = True
RERANK_CANDIDATE_MULTIPLIER = 3
RERANK_MAX_CANDIDATES = 20

# Таймаут LLM-реранка памяти (сек). При превышении — откат на порядок по _score.
RERANK_TIMEOUT = 4.0
# Soft-switch отключения thinking (Qwen3: " /no_think"). Добавляется к последнему
# user-сообщению во ВСЕХ вызовах без режима рассуждений (служебные вызовы, tool-decide,
# обычный стрим), чтобы модель не тратила токены на скрытое reasoning.
# Пустая строка "" — отключить (если модель не поддерживает такой переключатель).
LLM_NO_THINK_SUFFIX = " /no_think"
# Температура финального ответа, когда он опирается на инструменты/поиск (меньше выдумок).
GROUNDED_ANSWER_TEMP = 0.4

# -------------------------------
# Верификация финального ответа (критик) — пункт №3
# -------------------------------
# Дешёвый второй проход LLM после генерации ответа: проверяет, нет ли в
# ответе конкретных фактических утверждений, не подтверждённых тем, что
# реально было передано модели (память/поиск/результаты инструментов).
# Не переписывает ответ — только добавляет короткую пометку, если находит
# подозрительные утверждения. Короткие/светские реплики не проверяются
# (VERIFICATION_MIN_WORDS), чтобы не тратить лишний вызов зря.
RESPONSE_VERIFICATION_ENABLED = True
VERIFICATION_MIN_WORDS = 12
VERIFICATION_MAX_TOKENS = 150

# -------------------------------
# Планирование подзадач перед ReAct-циклом инструментов — пункт №4
# -------------------------------
# ToolRouter.run() раньше был полностью реактивным: на каждом раунде модель
# заново решала, какой СЛЕДУЮЩИЙ инструмент вызвать, не имея явного плана на
# составной запрос ("сравни X и Y, потом посчитай Z"). Для запросов, которые
# эвристически выглядят как составные (см. TOOL_PLANNING_MIN_LEN и маркеры
# в tool_router.py), делаем один дешёвый предварительный вызов, который
# раскладывает запрос на список подзадач, и передаём этот список как
# ориентир в промпт выбора инструмента на каждом раунде.
TOOL_PLANNING_ENABLED = False  # отключено: 2 доп. LLM-вызова на каждый составной запрос
TOOL_PLANNING_MIN_LEN = 140
MAX_SUBTASKS = 4

# -------------------------------
# Параллельное выполнение инструментов внутри одного ReAct-раунда — пункт №5
# -------------------------------
# Если модель одним раундом решила вызвать несколько независимых
# инструментов (например native tool_calls с 2-3 вызовами), они раньше
# выполнялись строго по очереди (await в цикле) — впустую тратя время на
# ожидание, если инструменты не зависят друг от друга. TOOL_PARALLEL_EXECUTION
# включает asyncio.gather для вызовов одного раунда.
TOOL_PARALLEL_EXECUTION = True

# -------------------------------
# Автоинжекция памяти в промпт браузерного чата (ai_assistant.py)
# -------------------------------
# router.retrieve() всегда возвращает top_k результатов (ближайшие соседи по
# эмбеддингам почти всегда находятся, даже для нерелевантных сообщений вроде
# "нарисуй кота"). Без порога эти слаборелевантные факты безусловно попадали
# в блок "КОНТЕКСТ ИЗ ДОЛГОСРОЧНОЙ ПАМЯТИ", который системный промпт называет
# самым надёжным источником — отсюда "путаница" в чате, которой нет в MCP
# (там recall — явный инструмент, вызывается по решению внешнего клиента, а
# не подмешивается в каждое сообщение). Ниже этого порога факт всё ещё
# участвует в predict_next/uncertainty/working memory, но не попадает в текст
# промпта. Подберите под свою модель эмбеддингов, если понадобится.
MEMORY_CONTEXT_MIN_SCORE = 0.15
# -------------------------------
# Формирование концептов (дополнительно)
# -------------------------------
CONCEPT_MERGE_THRESHOLD = 0.80          # порог для объединения с существующим концептом
CONCEPT_REFRESH_MEMBERS_DELTA = 3       # минимальное число новых членов для перегенерации текста
# ------------------------------- Интеллект-пакет (GCN/intellect.py) -------------------------------
# A. Заземлённый синтез ответа: модель обязана цитировать источники [N] и
#    не выдумывать факты вне переданного контекста.
GROUNDED_ANSWER_ENABLED = True
GROUNDED_MAX_SOURCES = 8
# ИСПРАВЛЕНИЕ (дублирование списка источников в чате): раньше ensure_citations
# при отсутствии [N] в ответе модели дописывала в САМ ТЕКСТ ответа блок
# "=== СПИСОК ИСТОЧНИКОВ ===" — а фронтенд отдельно, независимо от текста
# ответа, рендерит собственный блок "🔍 Источники:" из search_meta["sources"]
# (push через SSE). В итоге пользователь видел один и тот же список источников
# дважды. UI-блок уже гарантирует видимость источников независимо от того,
# процитировала их модель инлайн или нет, поэтому текстовый fallback внутри
# ensure_citations больше не нужен — оставлен только как отключаемая опция.
GROUNDED_APPEND_SOURCES_FALLBACK = False
# B. Санитайзер фактов из поиска: градация scope/confidence по доверию домена
#    (см. intellect.sanitize_search_facts). Отключение вернёт старое поведение
#    "всё в global с confidence 0.9".
SEARCH_FACT_SANITIZER_ENABLED = True
# C. Подзапросный retrieval для составных вопросов (retrieve по subqueries).
SUBQUERY_RETRIEVAL_ENABLED = True
MAX_RETRIEVE_SUBQUERIES = 3
# E. Финальный критик: сверка ответа с планом подзадач и добор пропущенного.
PLAN_CRITIC_ENABLED = True
PLAN_CRITIC_MAX_MISSED = 3


# =====================================================================
# Автономность и проактивность (GCN/autonomy.py)
# =====================================================================
# Мастер-выключатель движка. False — прежние фоновые циклы работают как раньше.
AUTONOMY_ENABLED = True
# Базовый интервал главного цикла движка (сек) + дробный джиттер, чтобы
# несколько пользователей не будили локальную LLM синхронно.
AUTONOMY_LOOP_INTERVAL = 45
AUTONOMY_LOOP_JITTER = 0.3
# Не запускать фоновые исследования, пока пользователь активно переписывается
# (последняя активность в чате младше этого окна) или идёт генерация ответа.
AUTONOMY_USER_ACTIVE_SUPPRESS_SECONDS = 300
# Очередь исследовательских тем: размер, TTL, ретраи.
RESEARCH_QUEUE_MAX_SIZE = 40
RESEARCH_TOPIC_TTL_SECONDS = 7 * 86400
RESEARCH_MAX_ATTEMPTS = 2
RESEARCH_RETRY_BACKOFF_SECONDS = 1800
# Бусты приоритета темы по источнику постановки в очередь.
RESEARCH_PRIORITY_SOURCE_BOOST = {
    "goal": 0.25, "goal_subtask": 0.20, "reflection": 0.15,
    "search_failure": 0.20, "contradiction": 0.15,
    "knowledge_gap": 0.10, "refresh": 0.05,
    # Эндогенные источники из MotivationEngine
    "curiosity_uncertainty": 0.12, "curiosity_skill_improvement": 0.10,
    "novelty_exploration": 0.08, "gap_stalled_goal": 0.15,
    "quality_improvement": 0.18, "quality_confidence_boost": 0.12,
    # Эндогенные identity-цели из MotivationEngine — не должны
    # проигрывать обычным research-темам
    "identity_stale": 0.15,
    "identity_diverging_heads": 0.20,
    "identity_all_invalidated": 0.25,
}
# Декомпозиция активных целей на проверяемые подзадачи (один раз на цель).
GOAL_DECOMPOSE_INTERVAL = 6 * 3600
# Актуализация устаревших временно-чувствительных фактов из памяти.
TIME_SENSITIVE_REFRESH_INTERVAL = 24 * 3600
TIME_SENSITIVE_REFRESH_MAX_PER_RUN = 3
# Дайджест проактивных уведомлений: находки копятся и одним LLM-вызовом
# отбираются достойные (максимум 2 за сброс) — вместо потока отдельных тостов.
DIGEST_ENABLED = True
DIGEST_MAX_ITEMS = 5
DIGEST_FLUSH_MIN_ITEMS = 1
DIGEST_MIN_INTERVAL_SECONDS = 45 * 60
DIGEST_MAX_NOTIFICATIONS_PER_DAY = 6
# Тихие часы (локальное время сервера): интервал, в который дайджест не шлётся.
QUIET_HOURS_START = 23
QUIET_HOURS_END = 8
# Обратная связь по уведомлениям: пользователь продолжил тему — источник
# ценнее (бонус к приоритету его тем); проигнорировал — притухает.
FEEDBACK_WINDOW_SECONDS = 3600
FEEDBACK_POSITIVE_BONUS = 0.15
FEEDBACK_NEGATIVE_DECAY = 0.05

# =====================================================================
# Делегирование субагентам (GCN/subagent.py)
# =====================================================================
# Если True — ToolRouter для "coder"-запросов (маркеры: .py/.js/traceback/
# read_code/search_code/github.com) делегирует обработку SubAgent-у роли
# CODER вместо обычного ReAct-цикла. Это ДАЁТ специализированный промпт
# и изолированный контекст, но ЗАБИРАЕТ plan_critic, scratchpad,
# verify_tool_result, трекинг плана и дедуп seen_calls/seen_errors —
# поэтому по умолчанию False. Включать только после проверки через
# agent_eval, что качество не падает.
SUBAGENT_DELEGATION_ENABLED = False


# Порог косинусного сходства для "рукопожатия" (remember_with_handshake).
# Если новый факт семантически ближе к предыдущему на эту величину,
# мы считаем, что голос ДЕЙСТВИТЕЛЬНО прочитал контекст, а не генерирует шум.
IDENTITY_HANDSHAKE_THRESHOLD = 0.25

# Порог консистентности ответа. Если косинусная близость вектора ответа
# к вектору "Ядра" ниже этого значения, критик помечает ответ как "смысловой дрейф".
IDENTITY_CONSISTENCY_THRESHOLD = 0.35

# Сколько фактов составлять "Ядро" (несущие стены графа)
IDENTITY_CORE_SIZE = 7


# [fast-path-patch]
# ===== Быстрый / медленный контур (fast_router.py) =====
FAST_ROUTER_ENABLED = True        # False -> всё как раньше (всегда ReAct)
FAST_ROUTER_THRESHOLD = 0.5       # p >= порога -> ToolRouter; ниже -> сразу стрим
FAST_ROUTER_EXPLORE = 0.05        # доля пограничных запросов, которые принудительно идут в TOOLS (сбор меток)
DEFER_POSTPROCESS = True          # plan_critic/verify/identity ПОСЛЕ [DONE], замечания -> уведомления
DEFER_MIN_RESPONSE_LEN = 400      # короткие ответы без поиска/инструментов вообще не проверяются
BG_LLM_MAX_WAIT = 300.0           # макс. ожидание «тишины» фоновым LLM-вызовом, сек
BG_LLM_COOLDOWN = 3.0             # сколько секунд тишины после ответа нужно фону, сек